# FishGame
Java游戏，飞翔的小鸟

## 运行截图

![截图](https://s2.ax1x.com/2019/04/02/Ay07FS.png)

## 推荐
**EasyWeb管系统模板**<br>
&emsp;一个开箱即用的后台模板，使用简单，模板丰富，包含传统ifram版、spa单页面路由版，[前往查看](https://easyweb.vip)。